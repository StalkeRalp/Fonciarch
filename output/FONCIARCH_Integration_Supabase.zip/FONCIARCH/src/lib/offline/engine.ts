import type { Title, Workspace } from "../models";
import { statuses } from "../models";
import { acknowledge, dependentIds, project, type LocalState, type Operation, type Receipt } from "./model";
import type { Persistence } from "./database";
export class SyncError extends Error { constructor(message: string, public status = 0) { super(message); } }
export interface Transport { read(): Promise<Workspace>; send(op: Operation): Promise<Workspace & { receipt: Receipt }> }
export const transport: Transport = {
  async read() { const r = await fetch("/api/workspace", { cache: "no-store", signal: AbortSignal.timeout(15000) }); const data = await r.json(); if (!r.ok) throw new SyncError(data.error || "Serveur inaccessible.", r.status); return data; },
  async send(op) { const r = await fetch("/api/workspace", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...op.input, action: op.action, operationId: op.id }), signal: AbortSignal.timeout(20000) }); const data = await r.json(); if (!r.ok) throw new SyncError(data.error || "Synchronisation impossible.", r.status); return data; },
};
function required(v: unknown, name: string, limit = 200) { if (typeof v !== "string" || !v.trim() || v.length > limit) throw new Error(`${name} invalide.`); return v.trim(); }
export class OfflineEngine {
  constructor(private store: Persistence, private network: Transport) {}
  read() { return this.store.read(); }
  async enqueue(action: string, raw: Record<string, unknown>) {
    return this.store.change(state => {
      const view = project(state); const input = structuredClone(raw); const id = crypto.randomUUID(); const now = new Date().toISOString(); let entityId: string | undefined;
      const checkTitle = (p: Record<string, unknown>, seen: Title[]) => {
        p.number = required(p.number, "Numéro", 50).replace(/[\s-]/g, ""); p.category = String(p.category).toUpperCase();
        if (!/^\d+$/.test(String(p.number)) || !["A", "B", "C"].includes(String(p.category))) throw new Error("Vérifiez le numéro et la catégorie du titre.");
        if (!view.boxes.some(b => b.number === p.box)) throw new Error("Créez d’abord le box de rangement.");
        if (seen.some(t => t.number === p.number && t.category === p.category && t.id !== p.id)) throw new Error("Ce numéro et cette catégorie existent déjà.");
        if (p.id) { const old = view.titles.find(t => t.id === p.id); if (!old) throw new Error("Titre introuvable sur cet appareil."); if (old.box !== p.box) throw new Error("Utilisez Déplacer pour changer le box."); }
        else p.clientId = crypto.randomUUID();
        p.status ||= "Disponible"; if (!statuses.includes(p.status as typeof statuses[number])) throw new Error("Statut invalide.");
        p.notes = typeof p.notes === "string" ? p.notes.slice(0, 10000) : "";
      };
      if (action === "title") { checkTitle(input, view.titles); entityId = String(input.id || input.clientId); }
      else if (action === "box") { input.number = required(input.number, "Numéro du box", 30).replace(/^0+(?=\d)/, ""); if (!/^\d+$/.test(String(input.number)) || /^0+$/.test(String(input.number))) throw new Error("Numéro du box invalide."); if (view.boxes.some(b => b.number === input.number)) throw new Error("Ce box existe déjà."); input.clientId = crypto.randomUUID(); }
      else if (action === "move") { entityId = String(input.id); const old = view.titles.find(t => t.id === entityId); if (!old || old.box === input.box || !view.boxes.some(b => b.number === input.box)) throw new Error("Choisissez un autre box existant."); input.reason = required(input.reason, "Motif", 2000); }
      else if (action === "settings") { for (const key of ["name", "cadastre", "location"]) input[key] = required(input[key], "Informations du service"); }
      else if (action === "import") { if (!Array.isArray(input.rows) || !input.rows.length || input.rows.length > 5000) throw new Error("Import limité à 5 000 lignes."); const seen = [...view.titles]; for (const row of input.rows as Record<string, unknown>[]) { delete row.id; checkTitle(row, seen); seen.push({ id: String(row.clientId), number: String(row.number), category: String(row.category) } as Title); } }
      else throw new Error("Cette opération n’est pas disponible hors connexion.");
      const previous = entityId ? [...state.operations].reverse().find(op => op.entityId === entityId || (op.action === "import" && (op.input.rows as Record<string, unknown>[]).some(r => r.clientId === entityId))) : undefined;
      const op: Operation = { id, action, input, createdAt: now, entityId, dependsOn: previous?.id, state: "pending" };
      return { ...state, operations: [...state.operations, op] };
    });
  }
  async sync(onChange: (state: LocalState) => void = () => {}) {
    const remote = await this.network.read();
    let state = await this.store.change(local => {
      if (local.base.backendId && remote.backendId && local.base.backendId !== remote.backendId && local.operations.length) throw new Error("La source des données a changé. Exportez puis traitez les saisies en attente avant de changer de serveur.");
      return { ...local, base: remote, lastSync: new Date().toISOString() };
    }); onChange(state);
    while (state.operations.length) {
      const op = state.operations[0]; if (op.state === "conflict") return state;
      try {
        const result = await this.network.send(op);
        if (result.receipt?.id !== op.id) throw new Error("Le serveur n’a pas confirmé cette opération. Elle reste en attente.");
        state = await this.store.change(current => acknowledge(current, result, result.receipt)); onChange(state);
      } catch (error) {
        if (error instanceof SyncError && error.status >= 400 && error.status < 500 && ![408, 429].includes(error.status)) {
          let latest = state.base;
          try { latest = await this.network.read(); } catch { /* La version locale reste disponible. */ }
          state = await this.store.change(current => ({ ...current, base: latest.backendId === current.base.backendId ? latest : current.base, operations: current.operations.map(x => x.id === op.id ? { ...x, state: "conflict", error: error.message } : x) })); onChange(state); return state;
        }
        throw error;
      }
    }
    return state;
  }
  async resolve(id: string, choice: "server" | "local") {
    return this.store.change(state => {
      const op = state.operations.find(x => x.id === id); if (!op) return state;
      if (choice === "server") { const ids = dependentIds(state.operations, id); return { ...state, operations: state.operations.filter(x => !ids.has(x.id)) }; }
      const current = state.base.titles.find(t => t.id === op.input.id);
      if (!["title", "move"].includes(op.action) || !current) throw new Error("Cette saisie ne peut pas remplacer un titre existant. Exportez-la avant d’écarter l’opération puis corrigez le numéro ou le box.");
      const nextId = crypto.randomUUID();
      return { ...state, operations: state.operations.map(x => x.id === id ? { ...x, id: nextId, state: "pending", error: undefined, dependsOn: undefined, input: { ...x.input, updatedAt: current.updatedAt } } : x.dependsOn === id ? { ...x, dependsOn: nextId } : x) };
    });
  }
}
